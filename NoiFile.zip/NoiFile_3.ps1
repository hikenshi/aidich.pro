$ErrorActionPreference = "Stop"

# Windows equivalent of NoiFile_3.py (no Python required).
# Usage:
#   1) Put this script in the folder containing your .txt chapters
#   2) Double-click run_noifile_3.cmd (recommended) or run:
#        powershell -ExecutionPolicy Bypass -File .\NoiFile_3.ps1

$OutFile = "combined.txt"

function Convert-ChineseNumberSmart {
  param(
    [Parameter(Mandatory = $true)]
    [string]$Text
  )

  $s = $Text.Trim()
  if ($s -match '^\d+$') { return [int64]$s }

  # Allow mixed digits inside (e.g. "12" already handled; "一2三" treated best-effort).
  $map = @{
    '零' = 0; '一' = 1; '二' = 2; '三' = 3; '四' = 4; '五' = 5; '六' = 6; '七' = 7; '八' = 8; '九' = 9;
  }

  # Parse up to 万 (10^4). Supports forms like:
  #   十二=12, 二十=20, 一百九十=190, 一千零二=1002, 一万二千三百四十五=12345
  $total = [int64]0
  $section = [int64]0
  $number = [int64]0

  foreach ($ch in $s.ToCharArray()) {
    if ($ch -ge '0' -and $ch -le '9') {
      $number = [int64]([string]$ch)
      continue
    }

    if ($map.ContainsKey([string]$ch)) {
      $number = [int64]$map[[string]$ch]
      continue
    }

    switch ([string]$ch) {
      '十' {
        if ($number -eq 0) { $number = 1 }
        $section += $number * 10
        $number = 0
      }
      '百' {
        if ($number -eq 0) { $number = 1 }
        $section += $number * 100
        $number = 0
      }
      '千' {
        if ($number -eq 0) { $number = 1 }
        $section += $number * 1000
        $number = 0
      }
      '万' {
        $section += $number
        $number = 0
        $total += $section * 10000
        $section = 0
      }
      default {
        # Unknown char (e.g. punctuation): ignore.
      }
    }
  }

  return ($total + $section + $number)
}

function Get-ChapterNumber {
  param(
    [Parameter(Mandatory = $true)]
    [string]$FileName
  )

  # Prefer "第...章"
  $m = [regex]::Match($FileName, '第([一二三四五六七八九十百千万零\d]+)章')
  if ($m.Success) {
    try {
      return [int64](Convert-ChineseNumberSmart $m.Groups[1].Value)
    } catch {
      # fallthrough
    }
  }

  # Fallback: numeric prefix like 182. or 182_
  $m2 = [regex]::Match($FileName, '^(\d+)[._]')
  if ($m2.Success) {
    try { return [int64]$m2.Groups[1].Value } catch { }
  }

  # "番外" goes near the end (but before completely unknown)
  if ($FileName.Contains('番外')) { return [int64]100000000000 }

  # Unknown -> last
  return [int64]1000000000000
}

$metadataFile = $null
# Be strict about metadata being a file (not a folder). Prefer metadata.txt if both exist.
if (Test-Path -LiteralPath "metadata.txt" -PathType Leaf) { $metadataFile = "metadata.txt" }
elseif (Test-Path -LiteralPath "metadata" -PathType Leaf) { $metadataFile = "metadata" }

# Gather .txt files excluding output + metadata.txt (to match Python behavior)
$txtFiles = Get-ChildItem -File -Filter "*.txt" |
  Where-Object { $_.Name -ne $OutFile -and $_.Name -ne "metadata.txt" }

$sorted = $txtFiles |
  ForEach-Object {
    [pscustomobject]@{
      Name    = $_.Name
      FullName = $_.FullName
      Chapter = (Get-ChapterNumber $_.Name)
    }
  } |
  Sort-Object Chapter, Name

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$previousContent = $null

$sw = New-Object System.IO.StreamWriter((Join-Path (Get-Location) $OutFile), $false, $utf8NoBom)
try {
  if ($metadataFile) {
    $metaContent = (Get-Content -LiteralPath $metadataFile -Raw -Encoding UTF8).Trim()
    if ($metaContent.Length -gt 0) {
      $sw.Write($metaContent)
      $sw.Write("`r`n`r`n")
      $previousContent = $metaContent
    }
  }

  foreach ($f in $sorted) {
    $content = (Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8).Trim()
    if ($content -ne $previousContent) {
      $sw.Write($content)
      $sw.Write("`r`n`r`n")
      $previousContent = $content
    }
  }
} finally {
  $sw.Dispose()
}

Write-Host ("OK: Da noi xong {0} file. Ho tro: 182.第181章, 第一百九十章, 番外." -f $sorted.Count)
